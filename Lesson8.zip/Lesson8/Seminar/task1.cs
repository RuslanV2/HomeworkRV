﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Task1
{
    //Войнов Р.
    //1. С помощью рефлексии выведите все свойства структуры DateTime.
    internal class task1
    {


        static PropertyInfo GetPropertyInfo(object obj, string str)
        {
            return obj.GetType().GetProperty(str);
        }

        static void Main(string[] args)
        {
            DateTime dateTime = new DateTime();
            Type Svoistva = typeof(DateTime);
            foreach (var prop in Svoistva.GetProperties())
            {
                Console.WriteLine(prop.Name);
                Console.WriteLine(GetPropertyInfo(dateTime, prop.Name).GetValue(dateTime, null));
                Console.WriteLine("_____________________");
            }
  
            Console.ReadLine();
        }
        

    }

}

