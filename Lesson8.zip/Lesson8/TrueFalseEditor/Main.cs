﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TrueFalseEditor
{
    //Войнов Р
    //3.

//а) Создать приложение, показанное на уроке, добавив в него защиту от возможных ошибок
//(не создана база данных, обращение к несуществующему вопросу, открытие слишком большого файла и т.д.).
//б) Изменить интерфейс программы, увеличив шрифт, поменяв цвет элементов и добавив другие «косметические» улучшения на свое усмотрение.
//в) Добавить в приложение меню «О программе» с информацией о программе(автор, версия, авторские права и др.).
//г)* Добавить пункт меню Save As, в котором можно выбрать имя для сохранения базы данных(элемент SaveFileDialog).
    public partial class Main : Form
    {
        private TrueFalse database;
        private int k;

        public Main()
        {
            InitializeComponent();
            k = 0;
        }

        private void menuItemExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void menuItemNew_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog(); 
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                database = new TrueFalse(dlg.FileName);
                database.Add("Замля круглая?", true);
                database.Save();
                nudNumber.Minimum = 1;
                nudNumber.Maximum = 1;
                nudNumber.Value = 1;
                k = 1;
            }
        }

        private void menuItemOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                database = new TrueFalse(dlg.FileName);
                database.Load();
                nudNumber.Minimum = 1;
                nudNumber.Maximum = database.Count;
                nudNumber.Value = 1;
                k = 1;
            }
        }

        private void menuItemSave_Click(object sender, EventArgs e)
        {
            database.Save();
        }

        private void nudNumber_ValueChanged(object sender, EventArgs e)
        {
            tbQuestion.Text = database[(int)nudNumber.Value - 1].Text;
            cbTrue.Checked = database[(int)nudNumber.Value - 1].TrueFalse;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (k == 1)
            {
                database.Add($"#{database.Count + 1}", true);
                nudNumber.Maximum = database.Count;
                nudNumber.Value = database.Count;
            }
            else
            {
                MessageBox.Show("Не создана база данных", "Редактор вопросов",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (k == 1)
            {
                if (nudNumber.Value > 1)
                {
                    database.Remove((int)nudNumber.Value - 1);
                    nudNumber.Maximum--;
                    nudNumber.Value--;
                }
                else
                    MessageBox.Show("Так нельзя", "Редактор вопросов",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Не создана база данных", "Редактор вопросов",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

       
        private void авторToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Автор: Войнов Руслан Юрьевич  ", "Редактор вопросов",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void версияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Версия 1.0.0  ", "Редактор вопросов",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void авторскиеПраваToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Корпорация Шторм ", "Редактор вопросов",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void bvzAfqkfToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (k==1)
                MessageBox.Show("есть", "Редактор вопросов",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        
    }
}
