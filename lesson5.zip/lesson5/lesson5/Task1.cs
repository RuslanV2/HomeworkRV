﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace lesson5
{//Войнов Р.
 //1. Создать программу, которая будет проверять корректность ввода логина.
 //Корректным логином будет строка от 2 до 10 символов, содержащая только буквы латинского алфавита или цифры, при этом цифра не может быть первой:
 //а) без использования регулярных выражений;
 //б) ** с использованием регулярных выражений.

    internal class Task1
    {
        static void Main(string[] args)
        {

            Console.WriteLine(@"Введите Логин от 2 до 10 символов, содержащий только буквы латинского алфавита или цифры,
при этом цифра не может быть первой: ");
            string str1 = Console.ReadLine();


            //а) без использования регулярных выражений;
            string str2 = "0123456789";
            string str3 = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";

            int a = 0;

            if (str1.Length > 1 && str1.Length < 11)
            {
                for (int j = 0; j < str2.Length; j++)
                {
                    if (str1[0] == str2[j])
                    {
                        Console.WriteLine("Логин введен не корректно");
                        a = 1;
                    }
                }
                if (a != 1)
                {
                    for (int i = 0; i < str1.Length; i++)
                    {
                        if (i == a)
                        {
                            for (int j = 0; j < str2.Length; j++)
                            {
                                if (str1[i] == str2[j])
                                    a = a + 1;
                            }
                            for (int j = 0; j < str3.Length; j++)
                            {
                                if (str1[i] == str3[j])
                                    a = a + 1;
                            }

                        }
                        else
                            Console.WriteLine("Логин введен не корректно");

                    }
                }
                
            }
            else
                Console.WriteLine("Логин введен не корректно");
            if (str1.Length==a)
                Console.WriteLine("Логин введен корректно");

            //б) ** с использованием регулярных выражений.

            Regex regex = new Regex("^[A-Za-z]{1}[A-Za-z0-9]{1,9}");
            if (regex.IsMatch(str1) == true)
                Console.WriteLine("Логин введен корректно");
            else
                Console.WriteLine("Логин введен не корректно");


            Console.ReadLine();
        }
    }
}
