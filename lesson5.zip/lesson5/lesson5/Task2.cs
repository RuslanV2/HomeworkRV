﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lesson5
{   // Войнов Р.
    //2. Разработать статический класс Message, содержащий следующие статические методы для обработки текста:
    //а) Вывести только те слова сообщения, которые содержат не более n букв.
    //б) Удалить из сообщения все слова, которые заканчиваются на заданный символ.
    //в) Найти самое длинное слово сообщения.
    //г) Сформировать строку с помощью StringBuilder из самых длинных слов сообщения.
    //д) ***Создать метод, который производит частотный анализ текста. В качестве параметра в него передается массив слов и текст, в качестве результата метод
    //возвращает сколько раз каждое из слов массива входит в этот текст. Здесь требуется использовать класс Dictionary.
    internal class Task2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите сообщение:");
            Console.WriteLine("============================================");
            string message = Console.ReadLine();
            Console.WriteLine("============================================");
            Console.Write("Не более скольки букв должны содержать слова сообщения: ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("============================================");
            Message.PrintWords(message, n);
            Console.WriteLine("============================================");
            Console.WriteLine("============================================");
            Console.Write("На какой символ должны заканчиваться слова сообщения, которые надо удалить: "); 
            char I = char.Parse(Console.ReadLine());
            Console.WriteLine("============================================");
            Message.DelWords(message, I);
            Console.WriteLine("============================================");
            Message.MaxWords(message);
            Console.WriteLine("============================================");
            Message.MaxStWords(message);

            Console.ReadLine();

        }
    }
    public class Message
    {

        private static string[] separators = { ",", ".", "!", "?", ";", ":", " ", "(", ")" };

        //а) Вывести только те слова сообщения, которые содержат не более n букв.
        public static void PrintWords(string message, int n)
        {
            string[] words = message.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            Console.WriteLine("Слова сообщения не превышающие " + n + " букв:" );
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length <= n)
                    Console.Write(words[i] + "  ");
            }
            Console.WriteLine();
        }
        //б) Удалить из сообщения все слова, которые заканчиваются на заданный символ.-
        public static void DelWords(string message, char I)
        {
            StringBuilder sb = new StringBuilder(message);
            
            string[] words = message.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i][words[i].Length - 1] == I)
                    sb.Replace(words[i], "");
            }
            Console.WriteLine("Cообщение без слов заканчивающихся символом" + I + ":\n " + sb);

        }
        //в) Найти самое длинное слово сообщения.
        public static void MaxWords(string message)
        {
            string Max = "";
            string[] words = message.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > Max.Length)
                    Max = words[i];
            }
            Console.WriteLine("Самое длинное слово сообщения: " + Max);

        }
        //г) Сформировать строку с помощью StringBuilder из самых длинных слов сообщения.
        public static void MaxStWords(string message)
        {
            StringBuilder sb = new StringBuilder(1000);
            string Max = "";
            string[] words = message.Split(separators, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > Max.Length)
                    Max = words[i];
            }
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length == Max.Length)
                    sb.Append(words[i]+" ");
            }
            Console.WriteLine("Cамые длинные слова сообщения: " + sb);

        }
    }
}
