﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lesson5
{//Войнов Р.
 //3. *Для двух строк написать метод, определяющий, является ли одна строка перестановкой другой.

    internal class Task3
    {
        static void Main(string[] args)
        {


            Console.Write("Введите первую строку: ");
            string str1 = Console.ReadLine();
            Console.Write("Введите вторую строку: ");
            StringBuilder str2 = new StringBuilder(Console.ReadLine());
           
            if (str1.Length == str2.Length)
                StringPere.PrintWords(str1, str2);
            else
                Console.Write("Одна строка не является перестановкой другой, так как строки разной длины");

            Console.ReadLine();


            
        }
    }
    public class StringPere
    {

        public static void PrintWords(string str01, StringBuilder str02)
        {
          
            for (int i = 0; i < str01.Length; i++)
            {
                
                for (int j = 0; j < str02.Length; j++)
                {
                    if (str01[i] == str02[j])
                    {
                        str02.Remove(j, 1);
                        break;

                    }
                }
                
            }
            if (str02.Length == 0)
                Console.Write("Одна строка является перестановкой другой");
            else
                Console.Write("Одна строка не является перестановкой другой");

        }
    }
}
