﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson2
{
    internal class Program
    {
        static void Task1()
        {
            Console.WriteLine("===================");
            Console.WriteLine("Выполнение задачи 1");
            Console.WriteLine("Написать метод, возвращающий минимальное из трёх чисел.");
            Console.WriteLine("=======================================================");
            Console.WriteLine("Введите значения трех чисел:");
            Console.Write("a = ");
            double a = double.Parse(Console.ReadLine());

            Console.Write("b = ");
            double b = double.Parse(Console.ReadLine());

            Console.Write("c = ");
            double c = double.Parse(Console.ReadLine());

            if ((a < b && a < c) || (b == a && c > a) || (a == c && b > c))
            {
                Console.WriteLine($"Минимальное число {a}");
            }
            else
            {
                if ((b < a && b < c) || (b == c && a > c))
                {
                    Console.WriteLine($"Минимальное число {b}");
                }
                else
                {
                    if (c < a && c < b)
                    {
                        Console.WriteLine($"Минимальное число {c}");
                    }
                    else
                    {
                        Console.WriteLine($"У вас три одинаковых числа");
                    }
                }
            }
            Console.ReadLine();
        }

        static void Task2()
        {
            Console.WriteLine("===================");
            Console.WriteLine("Выполнение задачи 2");
            Console.WriteLine("Написать метод подсчета количества цифр числа.");
            Console.WriteLine("===================");
            Console.WriteLine("Введите целое чисело:");
            Console.Write("a = ");
            double a = double.Parse(Console.ReadLine());
            int col = 1;
            int des = 1;
            while (true)
            {
                if (a >= (10 * des))
                {
                    col++;
                    des = des * 10;
                }
                else
                {
                    break;
                }
            }
            if (col == 1)
            {
                Console.WriteLine($"В вашем числе {col} цыфра");
            }

            else
            {
                if (col==2 || col == 3 || col == 4)
                {
                    Console.WriteLine($"В вашем числе {col} цыфры");
                }
                else
                {
                    Console.WriteLine($"В вашем числе {col} цыфр");
                }
            }
            Console.ReadLine();


        }

        static void Task3()
        {
            Console.WriteLine("===================");
            Console.WriteLine("Выполнение задачи 3");
            Console.WriteLine("С клавиатуры вводятся числа, пока не будет введен 0.\nПодсчитать сумму всех нечетных положительных чисел.");
            Console.WriteLine("===================");
            int number = 0;
            int col = 0;
            do
            {
                Console.Write("Введите число: ");
                number = int.Parse(Console.ReadLine());

                if (((number % 2) > 0) && (number > 0))
                    col = col + number; 
                
            }
            while (number != 0 );

            Console.WriteLine("Cумму всех нечетных положительных чисел: " + col);
            Console.ReadLine();
        }

        static void Task4()
        {
            Console.WriteLine("===================");
            Console.WriteLine("Выполнение задачи 4");
            Console.WriteLine("Реализовать метод проверки логина и пароля. На вход метода подается логин и пароль. \nНа выходе истина, если прошел авторизацию, и ложь, если не прошел (Логин: root, Password: GeekBrains). \nИспользуя метод проверки логина и пароля, написать программу: пользователь вводит логин и пароль, \nпрограмма пропускает его дальше или не пропускает. \nС помощью цикла do while ограничить ввод пароля тремя попытками.");
            Console.WriteLine("===================");
            string log0 = "root";
            string parol0 = "GeekBrains";
            int col = 3;
            do
            {
                Console.Write("Введите логин: ");
                string log = Console.ReadLine();
                Console.Write("Введите пароль: ");
                string parol = Console.ReadLine();

                if ((log == log0) && (parol == parol0))
                {
                    Console.WriteLine(" _______________________");
                    Console.WriteLine("| Вы прошли авторизацию.|\n| Приступайте к работе. | ");
                    Console.WriteLine(" -----------------------");
                    break;
                }
                else
                {
                    col--;
                    Console.WriteLine("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                    Console.WriteLine("! Пароль или логин введены не верно !");
                    if (col == 2)
                        Console.WriteLine("!!!!! У вас осталось " + col + " попытки !!!!!!");
                    else
                    {
                        if (col == 1)
                            Console.WriteLine("!!!!! У вас осталось " + col + " попытка !!!!!!");
                        else
                        {
                            Console.WriteLine("!!!!! У вас осталось " + col + " попыток !!!!!!");
                            Console.WriteLine("!!!!!!!!! Вы заблокированы !!!!!!!!!!");
                        }
                        
                    }
                    Console.WriteLine("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
                }
            }
            while (col != 0);
            
            Console.ReadLine();
        }

        static void Task5()
        {
            Console.WriteLine("===================");
            Console.WriteLine("Выполнение задачи 5");
            Console.WriteLine("а) Написать программу, которая запрашивает массу и рост человека,");
            Console.WriteLine("   вычисляет его индекс массы и сообщает,");
            Console.WriteLine("   нужно ли человеку похудеть, набрать вес или всё в норме.");
            Console.WriteLine("б) Рассчитать, на сколько кг похудеть или сколько кг набрать для нормализации веса.");
            Console.WriteLine("===================");
            Console.Write("Ваш вес, кг: ");
            float massa = float.Parse(Console.ReadLine());
            Console.Write("Ваш рост, м: ");
            float rost = float.Parse(Console.ReadLine());

            float IMT = massa / (rost * rost);
            if (IMT>=18 && IMT<25)
            {
                Console.WriteLine("Ваш вес в норме");
            }
            else
            {
                if (IMT<18)
                {
                    float mass = 18 * rost * rost - massa;
                    Console.WriteLine($"Вам необходимо набрать вес на {mass:F1} кг");
                }
                else
                {
                    float mass = massa - 25 * rost * rost;
                    Console.WriteLine($"Вам необходимо сбросить вес на {mass:F1} кг");
                }
            }
            
            Console.ReadLine();
        }
        static void Task6()
        {
            Console.WriteLine("===================");
            Console.WriteLine("Выполнение задачи 6");
            Console.WriteLine("Написать программу подсчета количества «хороших» чисел в диапазоне от 1 до 1 000 000 000.");
            Console.WriteLine("«Хорошим» называется число, которое делится на сумму своих цифр.");
            Console.WriteLine("Реализовать подсчёт времени выполнения программы, используя структуру DateTime.");
            Console.WriteLine("===================");
            
            int good = 0;
            int znak = 0;
            for (int i = 1; i <= 1000000000; i++)
            {
                for (int t=i; t/10 >= 1; t = t % 10 )
                {
                    znak = znak + t % 10;
                }
                if (i % znak == 0)
                    good = good + 1;

            }
            Console.Write("Количество «хороших» чисел: " + good);
            Console.ReadLine();
        }

        static void Main(string[] args)
        {

            bool f = true;
            while (f)
            {
                Console.WriteLine("============");
                Console.WriteLine("Войнов Руслн");
                Console.WriteLine("============");
                Console.WriteLine("1 -> Задача 1");
                Console.WriteLine("2 -> Задача 2");
                Console.WriteLine("3 -> Задача 3");
                Console.WriteLine("4 -> Задача 4");
                Console.WriteLine("5 -> Задача 5");
                Console.WriteLine("6 -> Задача 6");
                Console.WriteLine("=================================");
                Console.WriteLine("0 -> Завершение работы приложения");
                Console.WriteLine("=================================");

                Console.Write("Введите номер задачи: ");
                int number = int.Parse(Console.ReadLine());

                switch (number)
                {
                    case 0:
                        Console.WriteLine("Завершение работы приложения ...");
                        f = false;
                        break;
                    case 1:

                        Task1();

                        break;
                    case 2:

                        Task2();
                        break;

                    case 3:

                        Task3();
                        break;

                    case 4:

                        Task4();
                        break;
                        
                    case 5:

                        Task5();
                        break;

                    case 6:

                        Task6();
                        break;


                    default:
                        Console.WriteLine("Некорректный номер задачи.\nПовторите попытку ввода.");
                        break;
                }
            }

            Console.ReadLine();
        }
    }
}
