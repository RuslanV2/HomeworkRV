﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Doubler
//Войнов Р.
//а) Добавить в программу «Удвоитель» подсчёт количества отданных команд удвоителю.
//б) Добавить меню и команду «Играть». При нажатии появляется сообщение, какое число должен получить игрок. Игрок должен получить это число за минимальное количество ходов.
//в) *Добавить кнопку «Отменить», которая отменяет последние ходы. Используйте библиотечный обобщенный класс System.Collections.Generic.Stack<int>Stack.
//Вся логика игры должна быть реализована в классе с удвоителем.
{
    public partial class Main : Form
    {

        private Random random = new Random();
        private int computerNumber;
        private int userNumber;
        private int kol;
        private int uN;
        private int k;

        public Main()
        {
            CenterToScreen();
            InitializeComponent();
            kol = 0;
            userNumber = 0;
            uN = 0;
            k = 0;

            UpdateGameState(userNumber, random.Next(50), kol, uN, k);

        }

        private void UpdateGameState(int userNumber)
        {
            lbUserNumber.Text = $"Текущее число: {userNumber}";
        }

        private void UpdateGameState(int userNumber, int computerNumber, int kol, int uN, int k)
        {
            UpdateGameState(userNumber);
            this.computerNumber = computerNumber;
            this.kol = kol;
            this.uN = uN;
            this.k = k;
            lbComputerNumber.Text = $"Получите число: {computerNumber}";
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            userNumber = 0;
            kol = 0;
            uN = 0;
            k = 0;

            UpdateGameState(userNumber, random.Next(50),kol, uN, k);
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            //userNumber = userNumber + 1;
            uN = userNumber;
            k = kol;
            ++kol;
            UpdateGameState(++userNumber);
            CheckWin();
        }

        private void btnOtmena_Click(object sender, EventArgs e)
        {
            kol = k;
            UpdateGameState(userNumber = uN);

        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            // userNumber = userNumber * 2;
            uN = userNumber;
            k = kol;
            ++kol;
            UpdateGameState(userNumber *= 2);
            CheckWin();
        }

        private void CheckWin()
        {
            if (computerNumber == userNumber)
            {
                MessageBox.Show("Вы успешно завершили игру, количество отданных команд: " + kol, "Удвоитель",
                    MessageBoxButtons.OK, MessageBoxIcon.Information); ;
                if (MessageBox.Show("Желаете сыграть еще раз?", "Удвоитель",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    userNumber = 0;
                    kol = 0;
                    uN = 0;
                    k = 0;

                    UpdateGameState(userNumber, random.Next(50),kol, uN, k);
                }
                else
                {
                    Close();
                }
            }
        }
    }
}
