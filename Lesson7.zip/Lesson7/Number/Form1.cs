﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Number
{
    //Войнов Р
    //2. Используя Windows Forms, разработать игру «Угадай число». Компьютер загадывает число от 1 до 100,
    //а человек пытается его угадать за минимальное число попыток. Компьютер говорит, больше или меньше загаданное число введенного.
    //a) Для ввода данных от человека используется элемент TextBox;
    //б) ** Реализовать отдельную форму c TextBox для ввода числа.
    public partial class Form1 : Form

    {
        private Random random = new Random();
        
        private int computerNumber;
        private int kol;

        public Form1()
        {
            CenterToScreen();
            InitializeComponent();
            label2.Text = "Угадай его";
            kol = 0;
            computerNumber = random.Next(100);
        }

      
        private void btnCheck_Click(object sender, EventArgs e)
        {
            int userNumber = int.Parse(tbInputNumber.Text);

            if (computerNumber == userNumber)
            {
                label2.Text = "Угадал";
                kol++;
                MessageBox.Show("Количество попыток: " + kol, "Угадай число");
                if (MessageBox.Show("Желаете сыграть еще раз?", "Угадай число",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    computerNumber = random.Next(100);
                    tbInputNumber.Clear();
                    kol = 0;
                }
                else
                    Close();

            }
            else
            {
                if (computerNumber < userNumber)
                {
                    label2.Text = "Меньше";
                    kol++;
                    tbInputNumber.Clear();
                }
                else
                {
                    if (computerNumber > userNumber)
                    {
                        label2.Text = "Больше";
                        kol++;
                        tbInputNumber.Clear();

                    }
                    
                }
                    
            }

        }

        private void tbInputNumber_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
