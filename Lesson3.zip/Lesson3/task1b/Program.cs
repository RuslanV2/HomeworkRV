﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1bv
{//1 б) Дописать класс Complex, добавив методы вычитания и произведения чисел. Проверить работу класса.
//   в) Добавить диалог с использованием switch демонстрирующий работу класса.

    /// <summary>
    /// Комплексное число
    /// </summary>
    class ComplexClass
    {
        /// <summary>
        /// Мнимая часть комплексного числа
        /// </summary>
        private double im;

        /// <summary>
        /// Действительная часть комплексного числа
        /// </summary>
        private double re;

        public double Re
        {
            get
            {
                return re;

            }
            set
            {
                if (value == 0)
                {
                    throw new Exception("На ноль делить нелья!");
                }
                re = value;
            }
        }


        public ComplexClass()
        {

        }

        public ComplexClass(double re, double im)
        {
            if (re == 0)
            {
                throw new Exception("На ноль делить нелья!");
            }

            this.re = re;
            this.im = im;
        }

        /// <summary>
        /// Сложение комплексных чисел
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public ComplexClass Plus(ComplexClass x)
        {
            return new ComplexClass(re + x.re, im + x.im);
        }

        /// <summary>
        /// Вычитание комплексных чисел
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public ComplexClass Minys(ComplexClass x)
        {
            return new ComplexClass(re - x.re, im - x.im);
        }
        /// <summary>
        /// Произведение комплексных чисел
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public ComplexClass Ymnojenie(ComplexClass x)
        {
            return new ComplexClass(re * x.re - im * x.im,  x.re * im + re * x.im);
        }

        public override string ToString()
        {
            return $"{re} + {im}i";
            
        }
    }

    internal class Sample03
    {
        static void Main(string[] args)
        {
            Console.Write("(1) Введите действительную часть комплексного числа: ");
            double Re = double.Parse(Console.ReadLine());
            Console.Write("(1) Введите мнимую часть комплексного числа: ");
            double Im = double.Parse(Console.ReadLine());
            ComplexClass complex01 = new ComplexClass(Re, Im);
            

            

            Console.Write("(2) Введите действительную часть комплексного числа: ");
            double Re1 = double.Parse(Console.ReadLine());
            Console.Write("(2) Введите мнимую часть комплексного числа: ");
            double Im1 = double.Parse(Console.ReadLine());
            ComplexClass complex02 = new ComplexClass(Re1, Im1);

            Console.WriteLine($"Первое комплексное число: {complex01}");
            Console.WriteLine($"Второе комплексное число: {complex02}");


            
            
            

            bool f = true;
            while (f)
            {
                Console.WriteLine("Что сделать?");
                Console.WriteLine("===================");
                Console.WriteLine("1 -> Сложение чисел");
                Console.WriteLine("2 -> Вычитание чисел");
                Console.WriteLine("3 -> ЗПроизведение чисел");
                Console.WriteLine("0 -> Завершение работы приложения");
                Console.WriteLine("===================");

                Console.Write("Введите номер: ");
                int number = int.Parse(Console.ReadLine());
                switch (number)
                {
                    case 0:
                        Console.WriteLine("Завершение работы приложения ...");
                        f = false;
                        break;
                    case 1:

                        Console.WriteLine($"Сумма комплексных чисел {complex01} и {complex02} = {complex01.Plus(complex02)}");

                        break;
                    case 2:

                        Console.WriteLine($"Разность комплексных чисел {complex01} и {complex02} = {complex01.Minys(complex02)}");
                        break;

                    case 3:

                        Console.WriteLine($"Произведение комплексных чисел {complex01} и {complex02} = {complex01.Ymnojenie(complex02)}");
                        break;

                    default:
                        Console.WriteLine("Некорректный номер задачи.\nПовторите попытку ввода.");
                        break;
                }
                     
            }
            Console.ReadLine();
        }
    }
}
