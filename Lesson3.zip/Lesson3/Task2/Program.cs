﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{//2. С клавиатуры вводятся числа, пока не будет введён 0 (каждое число в новой строке). Требуется подсчитать сумму всех нечётных положительных чисел. Сами числа и сумму вывести на экран, используя tryParse.
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===================");
            Console.WriteLine("Выполнение задачи 3");
            Console.WriteLine("С клавиатуры вводятся числа, пока не будет введен 0.\nПодсчитать сумму всех нечетных положительных чисел.");
            Console.WriteLine("===================");
            int number = 0;
            int col = 0;
            string s = " ";
        

            do
            {
                Console.Write("Введите целое число: ");
                if (int.TryParse(Console.ReadLine(), out number))
                {
                    if (((number % 2) > 0) && (number > 0))
                    {
                        col = col + number;
                        s = s + number + " ";
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели или некорректное число.");
                    number = 1;
                }

            }
            while (number != 0);


            Console.WriteLine(" Введенные, все нечетные положительные чисела: " + s);
            Console.WriteLine(" Cумма этих чисел: " + col);
            Console.ReadLine();
        }
    }
}
