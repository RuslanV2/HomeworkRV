﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lesson4

{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Войнов Р.
            //1. Дан целочисленный массив из 20 элементов. Элементы массива могут принимать целые значения от –10 000 до 10 000 включительно.
            //Заполнить случайными числами. Написать программу, позволяющую найти и вывести количество пар элементов массива, в которых только одно число делится на 3.
            //В данной задаче под парой подразумевается два подряд идущих элемента массива.

            int a = 0;
            int[] massiv;
            massiv = new int[20];
                       
            Random random = new Random();

            for (int i = 0; i < 20; i++)
            {
                massiv[i] = random.Next(-10000, 10001);

            }
            PrintArray(massiv);

            for (int i = 1; i < 20; i++)
            {
                if (((massiv[i - 1] % 3== 0) && (massiv[i] % 3 != 0)) || ((massiv[i - 1] % 3 != 0) && (massiv[i] % 3 == 0)))
                {
                    a = a+1;
                }
                
            }


            Console.WriteLine("Ответ: " + a);
            Console.ReadLine();

        }

        public static void PrintArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"{arr[i]}\t");
            }
            Console.WriteLine();
        }

    }
}
