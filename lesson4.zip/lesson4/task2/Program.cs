﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace task2
{ //Войнов Р.
        //2. Реализуйте задачу 1 в виде статического класса StaticClass;

        //а) Класс должен содержать статический метод, который принимает на вход массив и решает задачу 1;
        //б) Добавьте статический метод для считывания массива из текстового файла.Метод должен возвращать массив целых чисел;
        //в)*Добавьте обработку ситуации отсутствия файла на диске.
    public class MyArray
    {
        #region Поля

        private int[] arr;

        #endregion

        #region Свойства

        public int this[int index]
        {
            get
            {
                return arr[index];
            }

            set
            {
                arr[index] = value;
            }
        }

        #endregion

        #region Конструкторы

        

        public MyArray(string fileName)
        {
            arr = LoadArrayFromFile(fileName);
        }

        #endregion
        public void Para()
        {
            if (arr != null)
            {
                int para = 0;
                for (int i = 1; i < 20; i++)
                {
                    if (((arr[i - 1] % 3 == 0) && (arr[i] % 3 != 0)) || ((arr[i - 1] % 3 != 0) && (arr[i] % 3 == 0)))
                    {
                        para = para + 1;
                    }
                }
                Console.WriteLine("Количество искомых пар элементов массива: " + para);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Я бы хотел найти пару но не в чем!");
                Console.WriteLine();
            }



        }


        #region Скрытые методы

        private int[] LoadArrayFromFile(string fileName)
        {
            if (!File.Exists(fileName))
                return null;

            int[] arr = new int[1000];
            int counter = 0;

            StreamReader sr = new StreamReader(fileName);

          while (!sr.EndOfStream)
            {
                int number = int.Parse(sr.ReadLine());
                arr[counter] = number;
                counter++;
            }

            int[] buf = new int[counter];

            Array.Copy(arr, buf, counter);

            sr.Close();
            return buf;
        }

        #endregion

        #region Публичные методы 

        public void PrintArray()
        {
            if (arr != null)
            {
                for (int i = 0; i < arr.Length; i++)
                {
                    Console.Write($"{arr[i]}  ");
                }
                Console.WriteLine();

            }
            else
                Console.WriteLine("Файл отсутствует");

        }

        #endregion

    }

    public class Sample02
    {

        static void Main(string[] args)
        {

           

            MyArray massiv = new MyArray(@"C:\Users\Врюти\Desktop\Руслан\Unity игры\С#\lesson4\task2\TextFile1.txt");

            massiv.PrintArray();
            massiv.Para();

            MyArray massiv1 = new MyArray(@"C:\Users\Врюти\Desktop\Руслан\Unity игры\С#\lesson4\task2\TextFile2.txt");

            massiv1.PrintArray();
            massiv1.Para();
            Console.ReadLine();
            

        }
    }
}
